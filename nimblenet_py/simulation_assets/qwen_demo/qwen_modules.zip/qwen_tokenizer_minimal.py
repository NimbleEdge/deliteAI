# Minimal Qwen2 Tokenizer for DeliteAI - Ultra simplified version
# No external dependencies, no decorators, uses ne_re instead of regex
from delitepy import ne_re

class Qwen2Tokenizer:
    """
    Ultra-minimal Qwen2 tokenizer for DeliteAI simulator.
    Simplified to avoid all unsupported Python features.
    """
    
    def __init__(self, config, vocab, bpe_merges):
        # Store config values
        self.eos_token_id = config.eos_token_id
        self.bos_token_id = config.bos_token_id
        self.pad_token_id = config.eos_token_id
        
        # Store vocabulary
        self.encoder = vocab
        self.decoder = {}
        for k, v in self.encoder.items():
            self.decoder[v] = k
        
        # Store BPE merges as a simple dict
        self.bpe_ranks = {}
        rank = 0
        for merge in bpe_merges:
            self.bpe_ranks[merge] = rank
            rank = rank + 1
        
        # Simple pattern for tokenization
        self.pattern = r"[a-zA-Z]+|[0-9]+|[^\sa-zA-Z0-9]+"
        
        # Special tokens
        self.unk_token = "<|endoftext|>"
        self.eos_token = "<|endoftext|>"
        self.pad_token = "<|endoftext|>"
        self.bos_token = None
        
        # Special token IDs
        if self.unk_token in self.encoder:
            self.unk_token_id = self.encoder[self.unk_token]
        else:
            self.unk_token_id = 0
            
        if "<|im_start|>" in self.encoder:
            self.im_start_id = self.encoder["<|im_start|>"]
        else:
            self.im_start_id = 0
            
        if "<|im_end|>" in self.encoder:
            self.im_end_id = self.encoder["<|im_end|>"]
        else:
            self.im_end_id = 0
    
    def tokenize(self, text):
        """Simple tokenization using ne_re"""
        matches = ne_re.findall(self.pattern, text)
        if matches == None:
            return []
        
        # For simplicity, just return the matches as tokens
        # In a real tokenizer, we'd apply BPE here
        tokens = []
        for match in matches:
            if match:
                tokens.append(match)
        return tokens
    
    def encode(self, text, add_special_tokens):
        """Encode text to token IDs - simplified version"""
        tokens = self.tokenize(text)
        
        # Convert tokens to IDs
        ids = []
        for token in tokens:
            if token in self.encoder:
                ids.append(self.encoder[token])
            else:
                ids.append(self.unk_token_id)
        
        # Add special tokens
        if add_special_tokens:
            if self.bos_token_id != None:
                ids = [self.bos_token_id] + ids
            if self.eos_token_id != None:
                ids = ids + [self.eos_token_id]
        
        return ids
    
    def decode(self, token_ids, skip_special_tokens):
        """Decode token IDs to text - simplified version"""
        # Handle single ID
        ids_list = []
        try:
            # Try to iterate - if it fails, it's a single ID
            for id in token_ids:
                ids_list.append(id)
        except:
            # Single ID case
            ids_list = [token_ids]
        
        # Convert IDs to tokens
        tokens = []
        for id in ids_list:
            if skip_special_tokens:
                if id == self.pad_token_id:
                    continue
                if id == self.eos_token_id:
                    continue
                if id == self.bos_token_id:
                    continue
                if id == self.unk_token_id:
                    continue
            
            if id in self.decoder:
                tokens.append(self.decoder[id])
            else:
                tokens.append("<unk>")
        
        # Join tokens
        text = "".join(tokens)
        return text
    
    def batch_decode(self, sequences, skip_special_tokens):
        """Decode multiple sequences"""
        decoded_texts = []
        for seq in sequences:
            decoded_texts.append(self.decode(seq, skip_special_tokens))
        return decoded_texts
    
    def apply_chat_template(self, messages, add_generation_prompt, tokenize, return_dict):
        """Apply chat template - simplified version"""
        text = ""
        
        for message in messages:
            role = ""
            if "role" in message:
                role = message["role"]
            content = ""
            if "content" in message:
                content = message["content"]
            
            if role == "system":
                text = text + "<|im_start|>system\n" + content + "<|im_end|>\n"
            elif role == "user":
                text = text + "<|im_start|>user\n" + content + "<|im_end|>\n"
            elif role == "assistant":
                text = text + "<|im_start|>assistant\n" + content + "<|im_end|>\n"
        
        if add_generation_prompt:
            text = text + "<|im_start|>assistant\n"
        
        if tokenize:
            input_ids = self.encode(text, add_special_tokens=False)
            
            if return_dict:
                # Create attention mask
                attention_mask = []
                for _ in input_ids:
                    attention_mask.append(1)
                
                result = {
                    "input_ids": input_ids,
                    "attention_mask": attention_mask
                }
                return result
            else:
                return input_ids
        else:
            return text 