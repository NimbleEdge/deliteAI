#!/usr/bin/env python3
#-*- coding: utf-8 -*-
from delitepy import nimblenet as nm
from delitepy import ne_re as re
from qwen_tokenizer_minimal import Qwen2Tokenizer
from tools import tools_dict
from tools import tool_schema as tls

# Simple config class to replace AutoConfig
class SimpleConfig:
    def __init__(self, config_dict):
        # Manually set common config attributes instead of using setattr
        if "eos_token_id" in config_dict:
            self.eos_token_id = config_dict["eos_token_id"]
        else:
            self.eos_token_id = 151643
            
        if "bos_token_id" in config_dict:
            self.bos_token_id = config_dict["bos_token_id"]
        else:
            self.bos_token_id = 151643
            
        if "vocab_size" in config_dict:
            self.vocab_size = config_dict["vocab_size"]
        else:
            self.vocab_size = 151936
            
        if "hidden_size" in config_dict:
            self.hidden_size = config_dict["hidden_size"]
        else:
            self.hidden_size = 1536
            
        if "intermediate_size" in config_dict:
            self.intermediate_size = config_dict["intermediate_size"]
        else:
            self.intermediate_size = 8960
            
        if "num_hidden_layers" in config_dict:
            self.num_hidden_layers = config_dict["num_hidden_layers"]
        else:
            self.num_hidden_layers = 24
            
        if "num_attention_heads" in config_dict:
            self.num_attention_heads = config_dict["num_attention_heads"]
        else:
            self.num_attention_heads = 12
            
        self.layer_types = None  # Always set this to None

# Load Qwen3 1.7B 4-bit model and tokenizer
model_id = "qwen3-1.7b"
qwenModel = nm.Model(model_id)
print("Model loaded successfully")

TOOL_CALL_START_TOKEN = "<tool_call>"
TOOL_CALL_END_TOKEN = "</tool_call>"
TOOL_RESPONSE_START_TOKEN = "<tool_response>"
TOOL_RESPONSE_END_TOKEN = "</tool_response>"
INITIAL_PROMPT = """You are a helpful assistant with access to tools. When you need to use a tool, format your response with JSON between <tool_call> and </tool_call> tokens.

Use this exact format: <tool_call>{"name": "function_name", "arguments": {"param": "value"}}</tool_call>
If a tool requires a argument you don't know the value of check if another tool can give you that information and call that tool first.
Always respond directly and call the appropriate tool when needed."""

def get_initial_message_block():
    return [
    {
        "role": "system",
        "content": INITIAL_PROMPT
    }
]

def execute_function_call(function_name, arguments, tools):
    """Execute a function call and return the result"""
    if function_name not in tools:
        return {"error": "Function "+function_name+" not found"}
    
    try:
        function = tools[function_name]
        result = {"error": "Function execution failed"}  # Initialize result
        
        # Handle each function explicitly to avoid ** operator
        if function_name == "get_weather":
            location = ""
            if "location" in arguments:
                location = arguments["location"]
            unit = "celsius"
            if "unit" in arguments:
                unit = arguments["unit"]
            result = function(location, unit)
        elif function_name == "calculate_math":
            expression = ""
            if "expression" in arguments:
                expression = arguments["expression"]
            result = function(expression)
        elif function_name == "get_current_time":
            timezone = "UTC"
            if "timezone" in arguments:
                timezone = arguments["timezone"]
            result = function(timezone)
        elif function_name == "get_current_location":
            result = function()
        else:
            result = {"error": "Unknown function: " + function_name}
        
        return result
    except Exception as e:
        return {"error": "Error executing "+function_name+": "+str(e)}

def format_tool_response(result):
    """Format tool execution result using token-based format"""
    return TOOL_RESPONSE_START_TOKEN+result+TOOL_RESPONSE_END_TOKEN

def execute_tool_call_with_response(function_name, arguments, tools):
    """Execute a function call and return both result and formatted response"""
    result = execute_function_call(function_name, arguments, tools)
    formatted_response = format_tool_response(result)
    return result, formatted_response

def parse_tool_calls_from_response(response_text, tools):
    """Parse tool calls from model response using multiple formats"""
    tool_calls = []

    # Method 2: Look for JSON-style tool calls: <tool_call>{"name": "func", "arguments": {...}}</tool_call>
    json_tool_pattern = r'<tool_call>\s*({.*?})\s*</tool_call>'
    json_matches = re.findall(json_tool_pattern, response_text, re.DOTALL)
    
    for json_str in json_matches:
        try:
            tool_data = nm.parse_json(json_str)
            func_name = tool_data["name"]
            arguments = tool_data["arguments"]
            
            if func_name in tools:
                tool_calls.append({
                    "function_name": func_name,
                    "arguments": arguments
                })
                print("✓ Parsed JSON tool call: "+func_name+"("+str(arguments)+")")
        except:
            print("⚠ Failed to parse JSON tool call: "+json_str)
    
    return tool_calls


def generate_with_model(conversation_messages, max_new_tokens, tool_schema, tokenizer, config):
    return "test"
    """Generate text using the loaded model with multi-turn conversation support"""
    # Use chat template with tools for multi-turn conversations
    print("---"*10)
    print("Conversation Messages:")
    print(conversation_messages)
    print("---"*10)

    # 2. Prepare inputs
    inputs = tokenizer.apply_chat_template(
      conversation_messages,
      True,  # add_generation_prompt
      True,  # tokenize
      True,  # return_dict
    )
    input_ids = inputs['input_ids']
    attention_mask = inputs['attention_mask']
    batch_size = input_ids.shape[0]
    position_ids = nm.tensor([[i for i in range(input_ids.shape[-1])] for _ in range(batch_size)], "int64")

    # Set config values
    num_key_value_heads = config.num_key_value_heads
    head_dim = config.hidden_size // config.num_attention_heads
    num_hidden_layers = config.num_hidden_layers
    eos_token_id = config.eos_token_id
    hidden_size = config.hidden_size
    # Initialize past cache values with correct shapes for ONNX model
    past_cache_values = {}
    
    # Check if config has layer_types (like LFM2)
    # Since we always set layer_types in SimpleConfig, we can just check if it's None
    if config.layer_types != None:
        for i in range(num_hidden_layers):
            if config.layer_types[i] == 'full_attention':
                for kv in ('key', 'value'):
                    # Use the ONNX model's expected head count (8) from the input shapes
                    past_cache_values['past_key_values.'+str(i)+'.'+kv] = nm.zeros([batch_size, 8, 0, head_dim], "float")
            elif config.layer_types[i] == 'conv':
                past_cache_values['past_conv.'+str(i)] = nm.zeros([batch_size, hidden_size, config.conv_L_cache], "float")
    else:
        # Standard transformer layers - use ONNX model's expected head count (8)
        for i in range(num_hidden_layers):
            for kv in ('key', 'value'):
                # Use 8 heads as expected by the ONNX model (from debug output)
                past_cache_values['past_key_values.'+str(i)+'.'+kv] = nm.zeros([batch_size, 8, 0, head_dim], "float")

    # 3. Generation loop
    generated_tokens = []
    for i in range(max_new_tokens):
        # Run model - returns a tuple where first element is logits, rest are cache values
        # Try passing cache as single dictionary parameter
        model_outputs = qwenModel.run(input_ids, attention_mask, position_ids, past_cache_values)
        
        # Extract logits (first element) and cache values (rest)
        logits = model_outputs[0]
        present_cache_values = []
        for j in range(1, len(model_outputs)):
            present_cache_values.append(model_outputs[j])

        # Update values for next generation loop
        next_token_id = nm.argmax(logits[0, -1, :])
        
        # Check for EOS token
        if next_token_id == eos_token_id:
            break
            
        generated_tokens.append(next_token_id)
        input_ids = nm.tensor([[next_token_id]], "int64")
        attention_mask = nm.concatenate([attention_mask, nm.ones_like(input_ids, "int64")], axis=-1)
        position_ids = position_ids[:, -1:] + 1
        
        # Update cache
        j = 0
        for key in past_cache_values:
            past_cache_values[key] = present_cache_values[j]
            j = j + 1

    # 4. Output result - decode only the generated tokens
    response = ""
    if generated_tokens:
        generated_tokens_array = nm.tensor([generated_tokens], "int64")
        response = tokenizer.batch_decode(generated_tokens_array, True)[0]  # True for skip_special_tokens

    return response.strip()


def handle_multi_step_request(user_prompt, max_steps, max_new_tokens, tools, tool_schema, tokenizer, config):
    """Handle requests that may require multiple tool calls and back and forth"""
    step_results = []
    conversation_messages = []  # Initialize as empty list, not None
    tool_context = {}  # Store results from previous tool calls
    
    for step in range(max_steps):
        print("\n--- Step " + str(step + 1) + " ---")
        if step == 0:
            conversation_messages = get_initial_message_block()
            conversation_messages.append({
                "role": "user", 
                "content": user_prompt
            })
        else: 
            conversation_messages.append({
                "role": "system", 
                "content": "Now use the result from the tool calls to answer the user's question. Call another tool if needed."
            })
        # Generate response
        try:
            response = generate_with_model(conversation_messages, max_new_tokens, tool_schema, tokenizer, config)
            print("Model Response: "+response)
            
            # Parse and execute tool calls
            tool_calls = parse_tool_calls_from_response(response, tools)
            tool_results = []
            
            if tool_calls:
                print("Executing "+str(len(tool_calls))+" tool call(s):")
                for call in tool_calls:
                    func_name = call["function_name"]
                    arguments = call["arguments"]
                    
                    print("  • "+func_name+"("+str(arguments)+")")
                    result, formatted_response = execute_tool_call_with_response(func_name, arguments, tools)
                    
                    # Store important results for future reference
                    if func_name == "get_current_location" and "location" in result:
                        tool_context["location"] = result["location"]
                    
                    tool_results.append({
                        "function": func_name,
                        "arguments": arguments,
                        "result": result
                    })
                    print("    Result: "+str(result))
            
            # Add assistant response to conversation
            conversation_messages.append({
                "role": "assistant",
                "content": response
            })
            
            # Add tool results to conversation as function messages
            for tool_result in tool_results:
                if "error" not in tool_result["result"]:
                    conversation_messages.append({
                        "role": "system",
                        "content": "The result of the tool " +tool_result['function']+" is: "+TOOL_RESPONSE_START_TOKEN+tool_result['result']+TOOL_RESPONSE_END_TOKEN
                    })
            prompt = "continuation"
            if step == 0:
                prompt = user_prompt
            # Store step result
            step_result = {
                "step": step + 1,
                "prompt": prompt,
                "response": response,
                "tool_calls": tool_calls,
                "tool_results": tool_results,
                "has_errors": len([True for tr in tool_results if "error" in tr["result"]]) > 0,
                "tool_context": tool_context,
                "conversation_messages": conversation_messages
            }
            step_results.append(step_result)
            
            # Check if all tool calls were successful
            if step_result["has_errors"]:
                print("⚠ Stopping due to tool execution errors")
                break
            
            # Simple continuation logic: if no tools were called, we're done
            if not tool_calls:
                print("✓ Completed after "+str(step + 1)+" step(s) - no tool calls needed")
                break
            
            # If we've reached max steps, stop
            if step >= max_steps - 1:
                print("✓ Reached maximum steps ("+str(max_steps)+")")
                break
            
            # If tools were executed, continue to next step to see if model wants to do more
            print("✓ Step "+str(step + 1)+" completed with "+str(len(tool_calls))+" tool call(s) - continuing...")
            
        except Exception as e:
            print("Error in step "+str(step + 1)+": "+str(e))
            prompt_text = ""
            if step == 0:
                prompt_text = user_prompt
            else:
                prompt_text = "continuation"
            step_results.append({
                "step": step + 1,
                "prompt": prompt_text,
                "error": str(e),
                "response": None,
                "tool_calls": [],
                "tool_results": [],
                "tool_context": tool_context,
                "conversation_messages": conversation_messages
            })
            break
    
    return step_results

def run_tool_calling_demo(input):
    """Run tool calling demonstration"""
    print("=== Qwen3 1.7B Tool Calling Demo ===\n")
    print("Model: "+model_id)
    vocab, merges, config_dict = input["vocab"], input["merges"], input["config_dict"]
    config = SimpleConfig(config_dict)

    # Ensure tokenizer has necessary tokens
    tokenizer = Qwen2Tokenizer(config, vocab, merges)

    # Get tool names without using list()
    tool_names = []
    for key in tools_dict.keys():
        tool_names.append(key)
    print("Available tools: "+str(tool_names))
    
    demo_prompts = [
        "What's the weather here today?",
        "Calculate 15 * 23",
        "What time is it in JST timezone?",
        "Where am I located?",
        "Get my location and check the weather there"
    ]
    
    i = 1
    for user_prompt in demo_prompts:
        print("\nDemo "+str(i)+": "+user_prompt)
        print("-" * 60)
        step_results = handle_multi_step_request(user_prompt, 4, 400, tools_dict, tls, tokenizer, config)
        # Show final summary
        print("\nMulti-step Summary:")
        for step_result in step_results:
            step_num = step_result["step"]
            tool_calls = []
            if "tool_calls" in step_result:
                tool_calls = step_result["tool_calls"]
            if tool_calls:
                print("  Step "+str(step_num)+": "+str(len(tool_calls))+" tool call(s)")
                for call in tool_calls:
                    func_name = call["function_name"]
                    print("    ✓ "+func_name)
        print("\n" + "="*60)
        i = i + 1